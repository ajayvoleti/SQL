-- 1.creating a DB named employee
create database if not exists employee;

-- using employee database 
use employee;

-- to display tables in the employee database
show tables;






alter table proj_table
modify project_id varchar(10) primary key
;

alter table emp_record_table
add foreign key(proj_id) references proj_table(project_id);


-- 3.query to fetch EMP_ID, FIRST_NAME, LAST_NAME, GENDER, and DEPARTMENT from the employee record table
select EMP_ID, FIRST_NAME, LAST_NAME, GENDER, DEPT from emp_record_table;







select * from emp_record_table limit 6;


-- 4 query to fetch the records with EMP_RATING is less than two
select EMP_ID, FIRST_NAME, LAST_NAME, GENDER, DEPT, EMP_RATING from emp_record_table where emp_rating < 2;


-- 4 query to fetch the records with EMP_RATING is greater than four
select EMP_ID, FIRST_NAME, LAST_NAME, GENDER, DEPT, EMP_RATING from emp_record_table where emp_rating > 4;





-- 4. query to fetch the records with EMP_RATING is greater than two and less than four
select EMP_ID, FIRST_NAME, LAST_NAME, GENDER, DEPT, EMP_RATING from emp_record_table where emp_rating in (2,4); 





-- 5 a query to concatenate the FIRST_NAME and the LAST_NAME of employees in the Finance department from the employee table and then give the resultant column alias as NAME
select concat(first_name,' ' ,last_name) as 'NAME' from emp_record_table where DEPT = 'FINANCE';




-- 6 a query to list only those employees who have someone reporting to them and number of reporting persons
select m.emp_id as Manager_ID, concat(m.first_name,' ',m.last_name) as Manager_name,  count(e.emp_id) as no_of_reporters
from emp_record_table e
join emp_record_table m
on e.manager_id = m.emp_id
group by m.emp_id;

-- 7 query to list down all the employees from the healthcare and finance departments using union
select a.emp_id, concat(a.first_name,' ', a.last_name) as Name, a.dept  from emp_record_table a where dept = 'healthcare'
union
select b.emp_id , concat(b.first_name,' ', b.last_name) as Name, b.dept  from emp_record_table b where dept = 'finance'
order by emp_id;

-- 8. query to list down employee details such as EMP_ID, FIRST_NAME, LAST_NAME, ROLE, DEPARTMENT, and EMP_RATING grouped by dept. 
-- Also include the respective employee rating along with the max emp rating for the department
select EMP_ID, FIRST_NAME, LAST_NAME, ROLE, DEPT, EMP_RATING, max(EMP_RATING)
from emp_record_table
group by dept ; 


-- 9. query to calculate the minimum and the maximum salary of the employees in each role
select role, max(salary) as Max_salary, min(salary) as Min_salary from emp_record_table group by role; 

-- 10. query to assign ranks to each employee based on their experience
select emp_id, concat(first_name,' ', last_name) as Name, exp as Year_Experience, dense_rank() over (order by exp desc) as Experience_rank
from emp_record_table;


-- 11. query to create a view that displays employees in various countries whose salary is more than six thousand
create view emp6000 as
select emp_id, concat(first_name,' ', last_name) as Name, country, salary 
from emp_record_table 
where salary>6000;
select * from emp6000;



-- 12.nested query to find employees with experience of more than ten years
select emp_id, concat(first_name, ' ', last_name) as Name, exp, salary from emp_record_table 
where emp_id in (select manager_id from emp_record_table);




-- 13.query to create a stored procedure to retrieve the details of the employees whose experience is more than three years
delimiter &&
create procedure exp_above3()
begin
select * from emp_record_table where exp > 3;
end && 
delimiter ;
call exp_above3();


-- 14. query using stored functions in the project table to check whether the job profile assigned to each employee in the data science team matches the organization’s set standard.
delimiter $$
create function role_check( exp int) 
returns varchar(50)
deterministic
begin
declare StandardRole varchar(50);
	if exp <= 2 then set StandardRole = 'JUNIOR DATA SCIENTIST';
	elseif (exp > 2 AND exp <=5) then set StandardRole = 'ASSOCIATE DATA SCIENTIST';
	elseif (exp > 5 AND exp <=10) then set StandardRole = 'SENIOR DATA SCIENTIST';
	elseif (exp > 10 AND exp <=12 ) then set StandardRole = 'LEAD DATA SCIENTIST';
	elseif (exp > 12 AND exp <=16 ) then set StandardRole = 'MANAGER';
	end if;
return (StandardRole);
end $$
delimiter ;

select emp_id, concat(first_name, ' ' , last_name) as Name, exp, role as Actual_Role,role_check(exp) Role_AsPerCompanyPolicy
from data_science_team; 



-- 15. index to improve the cost and performance of the query to find the employee whose FIRST_NAME is ‘Eric’ 
alter table emp_record_table 
  modify EMP_ID varchar(10) primary key,
  modify FIRST_NAME varchar(50),
  modify LAST_NAME varchar(50),
  modify GENDER varchar(5),
  modify ROLE varchar(50),
  modify DEPT varchar(50),
  -- EXP int DEFAULT NULL,
  modify COUNTRY varchar(50),
  modify CONTINENT varchar(50),
  -- SALARY int DEFAULT NULL,
  -- EMP_RATING int DEFAULT NULL,
  modify MANAGER_ID varchar(10),
  modify PROJ_ID varchar(50)
;



-- 15. index to improve the cost and performance of the query to find the employee whose FIRST_NAME is ‘Eric’ 
create index fname on emp_record_table (first_name);
select * from emp_record_table where first_name = 'Eric';




-- 16. query to calculate the bonus for all the employees, based on their ratings and salaries
--  (Use the formula: 5% of salary * employee rating).
select emp_id, concat(first_name,' ', last_name) as Name, salary, emp_rating, (0.05*salary*emp_rating) as Bonus
from emp_record_table;





-- 17.query to calculate the average salary distribution based on the continent and country
select continent, country, avg(salary) over(partition by country) as Country_Avg_Salary,
 avg(salary) over(partition by continent) as Continent_Avg_Salary 
from emp_record_table;




